// This file is for adding JavaScript functionality
console.log("Welcome to the Manga Reader!");